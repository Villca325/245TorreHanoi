class PilaCompleta {
  List<int> datosPila;
  int maximo;
  PilaCompleta(this.datosPila,this.maximo);
}
